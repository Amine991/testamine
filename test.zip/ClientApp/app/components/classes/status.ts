﻿/* Defines the status entity */
export interface IStatus {
    StatusMessage: string;
    Success: boolean;
}