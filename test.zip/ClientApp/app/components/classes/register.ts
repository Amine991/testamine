﻿/* Defines the Registration entity */
export interface IRegister {
    userName: string;
    firstName: string;
    lastName: string;
    email: string;
    password: string;
}