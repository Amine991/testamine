﻿/* Defines the entity */
export interface ILoginStatus {
    status: string;
    isLoggedIn: boolean;
}