﻿/* Defines the Authentication entity */
export interface IAuthentication {
    userName: string;
    password: string;
}