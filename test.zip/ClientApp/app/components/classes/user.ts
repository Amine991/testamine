﻿/* Defines the user entity */
export interface IUser {
    userName: string;
    isLoggedIn: boolean;
}