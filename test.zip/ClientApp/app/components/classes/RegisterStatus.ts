﻿/* Defines the entity */
export interface IRegisterStatus {
    status: string;
    isSuccessful: boolean;
}